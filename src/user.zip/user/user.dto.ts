import { IsString } from 'class-validator';

export default class SingupUserDto {
  @IsString()
  readonly userEmail: string;

  @IsString()
  readonly userNickname: string;

  @IsString()
  readonly password: string;
}
